( function ( wp ) {
	const el = wp.element.createElement;
	const { InspectorControls, useBlockProps } = wp.blockEditor;
	const { PanelBody, RangeControl, ToggleControl } = wp.components;
	const ServerSideRender = wp.serverSideRender;

	wp.blocks.registerBlockType( 'sanroman/bandomovil', {
		edit( { attributes, setAttributes } ) {
			return el(
				'div',
				useBlockProps(),
				el(
					InspectorControls,
					null,
					el(
						PanelBody,
						{ title: 'Ajustes' },
						el( RangeControl, {
							label: 'Número de avisos',
							value: attributes.numero,
							min: 1,
							max: 10,
							onChange: ( numero ) => setAttributes( { numero } ),
						} ),
						el( ToggleControl, {
							label: 'Mostrar enlace a la app',
							checked: attributes.mostrarApp,
							onChange: ( mostrarApp ) => setAttributes( { mostrarApp } ),
						} )
					)
				),
				el( ServerSideRender, { block: 'sanroman/bandomovil', attributes } )
			);
		},
		save: () => null,
	} );
} )( window.wp );
