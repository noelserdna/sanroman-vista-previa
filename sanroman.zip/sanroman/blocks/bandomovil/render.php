<?php
/**
 * Bloque «Avisos de Bandomóvil».
 *
 * @var array $attributes
 */

$avisos = array_slice( sanroman_bandomovil_avisos(), 0, max( 1, (int) $attributes['numero'] ) );
$meses  = array( 'ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic' );
?>
<div <?php echo get_block_wrapper_attributes( array( 'class' => 'bandomovil' ) ); ?>>
	<?php if ( $attributes['mostrarApp'] ) : ?>
		<p class="bandomovil__app">
			<span class="bandomovil__sello">Publicados en Bandomóvil</span>
			Recíbelos al instante con la app «San Román de los Montes Informa».
			<a href="<?php echo esc_url( SANROMAN_BANDOMOVIL_APP ); ?>">Descargar la app</a>
		</p>
	<?php endif; ?>

	<?php if ( ! $avisos ) : ?>
		<p class="bandomovil__vacio">
			Ahora mismo no podemos mostrar los avisos.
			<a href="<?php echo esc_url( SANROMAN_BANDOMOVIL_URL ); ?>">Consúltalos en Bandomóvil</a>.
		</p>
	<?php else : ?>
		<ul class="bandomovil__lista">
			<?php foreach ( $avisos as $aviso ) : ?>
				<?php $partes = $aviso['iso'] ? explode( '-', $aviso['iso'] ) : array(); ?>
				<li class="bandomovil__aviso">
					<?php if ( $partes ) : ?>
						<time class="bandomovil__fecha" datetime="<?php echo esc_attr( $aviso['iso'] ); ?>">
							<span class="bandomovil__dia"><?php echo esc_html( $partes[2] ); ?></span>
							<span class="bandomovil__mes"><?php echo esc_html( $meses[ (int) $partes[1] - 1 ] . ' ' . $partes[0] ); ?></span>
						</time>
					<?php endif; ?>
					<div>
						<?php if ( $aviso['categoria'] ) : ?>
							<span class="bandomovil__categoria"><?php echo esc_html( $aviso['categoria'] ); ?></span>
						<?php endif; ?>
						<a class="bandomovil__titulo" href="<?php echo esc_url( $aviso['enlace'] ); ?>"><?php echo esc_html( $aviso['titulo'] ); ?></a>
						<?php if ( $aviso['adjunto'] ) : ?>
							<a class="bandomovil__pdf" href="<?php echo esc_url( $aviso['adjunto'] ); ?>">Documento en PDF<span class="solo-lector">: <?php echo esc_html( $aviso['titulo'] ); ?></span></a>
						<?php endif; ?>
					</div>
				</li>
			<?php endforeach; ?>
		</ul>
	<?php endif; ?>
</div>
