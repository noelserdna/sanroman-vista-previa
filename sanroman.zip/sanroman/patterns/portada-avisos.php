<?php
/**
 * Title: Portada · Avisos y bandos + fiestas
 * Slug: sanroman/portada-avisos
 * Categories: sanroman-portada
 * Description: Últimos avisos de Bandomóvil junto al calendario de fiestas del año.
 */
?>
<!-- wp:columns {"align":"wide","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"},"blockGap":{"left":"3rem"}}}} -->
<div class="wp-block-columns alignwide" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50)">
	<!-- wp:column {"width":"64%"} -->
	<div class="wp-block-column" style="flex-basis:64%">
		<!-- wp:group {"layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between","verticalAlignment":"bottom"}} -->
		<div class="wp-block-group">
			<!-- wp:heading -->
			<h2 class="wp-block-heading">Avisos y bandos</h2>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"fontSize":"small"} -->
			<p class="has-small-font-size"><a href="<?php echo esc_url( home_url( '/avisos-y-bandos/' ) ); ?>"><strong>Ver todos los avisos</strong></a></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:group -->
		<!-- wp:sanroman/bandomovil {"numero":4} /-->
	</div>
	<!-- /wp:column -->

	<!-- wp:column {"width":"36%"} -->
	<div class="wp-block-column" style="flex-basis:36%">
		<!-- wp:heading -->
		<h2 class="wp-block-heading">Fiestas del año</h2>
		<!-- /wp:heading -->
		<!-- wp:list {"className":"calendario-fiestas"} -->
		<ul class="wp-block-list calendario-fiestas">
			<!-- wp:list-item --><li><strong>Febrero o marzo</strong>Carnaval<br><span>Sardinas asadas · un día</span></li><!-- /wp:list-item -->
			<!-- wp:list-item {"className":"es-patronal"} --><li class="es-patronal"><strong>Semana del 15 de agosto</strong>Virgen del Buen Camino<br><span>Fiestas patronales: procesión, verbenas y festejos taurinos</span></li><!-- /wp:list-item -->
			<!-- wp:list-item --><li><strong>18 de noviembre</strong>San Román Mártir<br><span>Misa, procesión y judías con panceta</span></li><!-- /wp:list-item -->
		</ul>
		<!-- /wp:list -->
	</div>
	<!-- /wp:column -->
</div>
<!-- /wp:columns -->
