<?php
/**
 * Title: Portada · Bienvenida y buscador
 * Slug: sanroman/portada-bienvenida
 * Categories: sanroman-portada
 * Description: Titular, buscador con lo más buscado y foto del pueblo.
 */

$buscar = static fn( $termino ) => esc_url( add_query_arg( 's', $termino, home_url( '/' ) ) );
?>
<!-- wp:group {"align":"full","className":"bienvenida","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|60"}}},"backgroundColor":"granito","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull bienvenida has-granito-background-color has-background" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--60)">
	<!-- wp:columns {"verticalAlignment":"center","align":"wide","style":{"spacing":{"blockGap":{"left":"3rem"}}}} -->
	<div class="wp-block-columns alignwide are-vertically-aligned-center">
		<!-- wp:column {"verticalAlignment":"center","width":"46%"} -->
		<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:46%">
			<!-- wp:paragraph {"className":"antetitulo"} -->
			<p class="antetitulo">Sierra de San Vicente · Toledo</p>
			<!-- /wp:paragraph -->
			<!-- wp:heading {"level":1} -->
			<h1 class="wp-block-heading">Bienvenidos a San Román de los Montes</h1>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"textColor":"gris","fontSize":"large"} -->
			<p class="has-gris-color has-text-color has-large-font-size">Trámites, avisos y servicios del Ayuntamiento, a mano y en un solo sitio.</p>
			<!-- /wp:paragraph -->
			<!-- wp:search {"label":"¿Qué necesitas hacer?","placeholder":"Ej.: empadronamiento, licencia de obra…","buttonText":"Buscar","className":"buscador-portada"} /-->
			<!-- wp:group {"className":"mas-buscado","layout":{"type":"flex","flexWrap":"wrap"},"style":{"spacing":{"blockGap":"0.5rem"}}} -->
			<div class="wp-block-group mas-buscado">
				<!-- wp:paragraph {"textColor":"gris","fontSize":"small"} -->
				<p class="has-gris-color has-text-color has-small-font-size">Lo más buscado:</p>
				<!-- /wp:paragraph -->
				<!-- wp:buttons {"style":{"spacing":{"blockGap":"0.5rem"}}} -->
				<div class="wp-block-buttons">
					<!-- wp:button {"className":"is-style-pildora"} --><div class="wp-block-button is-style-pildora"><a class="wp-block-button__link wp-element-button" href="https://sanromandelosmontes.sedelectronica.es/">Empadronamiento</a></div><!-- /wp:button -->
					<!-- wp:button {"className":"is-style-pildora"} --><div class="wp-block-button is-style-pildora"><a class="wp-block-button__link wp-element-button" href="<?php echo $buscar( 'licencia de obra' ); ?>">Licencia de obra</a></div><!-- /wp:button -->
					<!-- wp:button {"className":"is-style-pildora"} --><div class="wp-block-button is-style-pildora"><a class="wp-block-button__link wp-element-button" href="<?php echo esc_url( home_url( '/contacto/' ) ); ?>">Cita previa</a></div><!-- /wp:button -->
					<!-- wp:button {"className":"is-style-pildora"} --><div class="wp-block-button is-style-pildora"><a class="wp-block-button__link wp-element-button" href="https://reservadeportes.com/AytoSanromandelosmontes.html">Pistas de pádel</a></div><!-- /wp:button -->
				</div>
				<!-- /wp:buttons -->
			</div>
			<!-- /wp:group -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column {"verticalAlignment":"center","width":"54%"} -->
		<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:54%">
			<!-- wp:image {"sizeSlug":"full","className":"foto-portada"} -->
			<figure class="wp-block-image size-full foto-portada"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/img/iglesia.jpg' ) ); ?>" alt="Iglesia parroquial de San Román con la fuente de la plaza"/><figcaption class="wp-element-caption">Iglesia parroquial de San Román</figcaption></figure>
			<!-- /wp:image -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
