<?php
/**
 * Title: La alcaldesa os habla
 * Slug: sanroman/portada-saludo
 * Categories: sanroman-portada, sanroman
 * Description: Foto de la alcaldesa sobre el rojo del escudo con su frase en un bocadillo y enlace al saludo completo.
 */
?>
<!-- wp:group {"align":"full","className":"franja-cita","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"0"}}},"backgroundColor":"rojo","textColor":"blanco","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull franja-cita has-blanco-color has-rojo-background-color has-text-color has-background" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:0">
	<!-- wp:columns {"align":"wide","style":{"spacing":{"blockGap":{"left":"2.5rem"}}}} -->
	<div class="wp-block-columns alignwide">
		<!-- wp:column {"verticalAlignment":"bottom","width":"34%","className":"columna-alcaldesa"} -->
		<div class="wp-block-column is-vertically-aligned-bottom columna-alcaldesa" style="flex-basis:34%">
			<!-- wp:image {"width":"380px","sizeSlug":"full","align":"center","className":"foto-alcaldesa","style":{"border":{"radius":"0px"}}} -->
			<figure class="wp-block-image aligncenter size-full is-resized foto-alcaldesa has-custom-border"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/img/alcaldesa.webp' ) ); ?>" alt="Luisa Nieto, alcaldesa de San Román de los Montes" style="border-radius:0px;width:380px"/></figure>
			<!-- /wp:image -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column {"verticalAlignment":"center","width":"66%","className":"columna-bocadillo"} -->
		<div class="wp-block-column is-vertically-aligned-center columna-bocadillo" style="flex-basis:66%">
			<!-- wp:quote {"className":"bocadillo"} -->
			<blockquote class="wp-block-quote bocadillo"><!-- wp:paragraph -->
			<p>Esperamos que penséis en el Ayuntamiento como la casa de todos, un lugar para ayudar y mejorar nuestra convivencia en el día a día.</p>
			<!-- /wp:paragraph --></blockquote>
			<!-- /wp:quote -->

			<!-- wp:paragraph {"className":"firma-alcaldesa"} -->
			<p class="firma-alcaldesa"><strong>Luisa Nieto</strong>, alcaldesa de San Román de los Montes<br><a href="<?php echo esc_url( home_url( '/saludo-del-alcalde/' ) ); ?>">Leer el saludo completo →</a></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
