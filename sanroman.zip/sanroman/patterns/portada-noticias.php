<?php
/**
 * Title: Portada · Noticias y anuncios
 * Slug: sanroman/portada-noticias
 * Categories: sanroman-portada
 * Description: La noticia más reciente destacada y las tres siguientes. Se rellena sola con las entradas.
 */
?>
<!-- wp:group {"align":"full","className":"seccion-noticias","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"backgroundColor":"granito","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull seccion-noticias has-granito-background-color has-background" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)">
	<!-- wp:group {"align":"wide","layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between","verticalAlignment":"bottom"}} -->
	<div class="wp-block-group alignwide">
		<!-- wp:group {"layout":{"type":"flex","orientation":"vertical"},"style":{"spacing":{"blockGap":"0.25rem"}}} -->
		<div class="wp-block-group">
			<!-- wp:heading -->
			<h2 class="wp-block-heading">Noticias y anuncios</h2>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"textColor":"gris"} -->
			<p class="has-gris-color has-text-color">Lo que pasa en San Román: actividades, obras, cultura y convocatorias.</p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:group -->
		<!-- wp:paragraph {"fontSize":"small"} -->
		<p class="has-small-font-size"><a href="<?php echo esc_url( home_url( '/noticias/' ) ); ?>"><strong>Todas las noticias</strong></a></p>
		<!-- /wp:paragraph -->
	</div>
	<!-- /wp:group -->

	<!-- wp:columns {"align":"wide","style":{"spacing":{"blockGap":{"left":"1.5rem"}}}} -->
	<div class="wp-block-columns alignwide">
		<!-- wp:column {"width":"60%"} -->
		<div class="wp-block-column" style="flex-basis:60%">
			<!-- wp:query {"queryId":21,"query":{"perPage":1,"pages":0,"offset":0,"postType":"post","order":"desc","orderBy":"date","inherit":false},"className":"noticia-destacada"} -->
			<div class="wp-block-query noticia-destacada">
				<!-- wp:post-template -->
					<!-- wp:post-featured-image {"isLink":true,"aspectRatio":"16/9","style":{"border":{"radius":"0px"}}} /-->
					<!-- wp:group {"className":"noticia__cuerpo","style":{"spacing":{"padding":{"top":"1.5rem","bottom":"1.75rem","left":"1.625rem","right":"1.625rem"},"blockGap":"0.5rem"}},"layout":{"type":"flow"}} -->
					<div class="wp-block-group noticia__cuerpo" style="padding-top:1.5rem;padding-right:1.625rem;padding-bottom:1.75rem;padding-left:1.625rem">
						<!-- wp:group {"layout":{"type":"flex","flexWrap":"wrap"},"style":{"spacing":{"blockGap":"0.75rem"}}} -->
						<div class="wp-block-group">
							<!-- wp:post-terms {"term":"category","className":"etiqueta-categoria"} /-->
							<!-- wp:post-date {"format":"j M Y"} /-->
						</div>
						<!-- /wp:group -->
						<!-- wp:post-title {"level":3,"isLink":true,"fontSize":"x-large"} /-->
						<!-- wp:post-excerpt {"excerptLength":30,"textColor":"gris"} /-->
					</div>
					<!-- /wp:group -->
				<!-- /wp:post-template -->
				<!-- wp:query-no-results -->
					<!-- wp:paragraph {"textColor":"gris"} -->
					<p class="has-gris-color has-text-color">Todavía no hay noticias publicadas.</p>
					<!-- /wp:paragraph -->
				<!-- /wp:query-no-results -->
			</div>
			<!-- /wp:query -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column {"width":"40%"} -->
		<div class="wp-block-column" style="flex-basis:40%">
			<!-- wp:query {"queryId":22,"query":{"perPage":3,"pages":0,"offset":1,"postType":"post","order":"desc","orderBy":"date","inherit":false},"className":"noticias-lista"} -->
			<div class="wp-block-query noticias-lista">
				<!-- wp:post-template {"style":{"spacing":{"blockGap":"1rem"}}} -->
					<!-- wp:group {"className":"noticia-mini","style":{"spacing":{"blockGap":"1rem"}},"layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"top"}} -->
					<div class="wp-block-group noticia-mini">
						<!-- wp:post-featured-image {"isLink":true,"width":"104px","height":"88px","style":{"border":{"radius":"8px"}}} /-->
						<!-- wp:group {"style":{"spacing":{"blockGap":"0.25rem"}},"layout":{"type":"flow"}} -->
						<div class="wp-block-group">
							<!-- wp:group {"layout":{"type":"flex","flexWrap":"wrap"},"style":{"spacing":{"blockGap":"0.5rem"}}} -->
							<div class="wp-block-group">
								<!-- wp:post-terms {"term":"category","className":"categoria-texto"} /-->
								<!-- wp:post-date {"format":"j M Y","fontSize":"x-small"} /-->
							</div>
							<!-- /wp:group -->
							<!-- wp:post-title {"level":3,"isLink":true,"fontSize":"medium"} /-->
						</div>
						<!-- /wp:group -->
					</div>
					<!-- /wp:group -->
				<!-- /wp:post-template -->
			</div>
			<!-- /wp:query -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
