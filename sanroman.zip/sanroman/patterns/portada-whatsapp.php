<?php
/**
 * Title: Portada · Canal de WhatsApp
 * Slug: sanroman/portada-whatsapp
 * Categories: sanroman-portada, sanroman
 * Description: Llamada destacada para unirse al canal de WhatsApp, con pasos y código QR.
 */

$canal = 'https://whatsapp.com/channel/0029VaTsvKSGzzKPsiTUxa1b';
?>
<!-- wp:group {"align":"wide","className":"franja-whatsapp","style":{"spacing":{"padding":{"top":"2.5rem","bottom":"2.5rem","left":"2.5rem","right":"2.5rem"},"margin":{"bottom":"var:preset|spacing|60"}},"border":{"radius":"16px"}},"backgroundColor":"whatsapp","textColor":"blanco","layout":{"type":"constrained","contentSize":"100%"}} -->
<div class="wp-block-group alignwide franja-whatsapp has-blanco-color has-whatsapp-background-color has-text-color has-background" style="border-radius:16px;margin-bottom:var(--wp--preset--spacing--60);padding-top:2.5rem;padding-right:2.5rem;padding-bottom:2.5rem;padding-left:2.5rem">
	<!-- wp:columns {"verticalAlignment":"center","style":{"spacing":{"blockGap":{"left":"2.5rem"}}}} -->
	<div class="wp-block-columns are-vertically-aligned-center">
		<!-- wp:column {"verticalAlignment":"center","width":"62%"} -->
		<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:62%">
			<!-- wp:paragraph {"className":"antetitulo antetitulo--claro"} -->
			<p class="antetitulo antetitulo--claro">Canal oficial de WhatsApp</p>
			<!-- /wp:paragraph -->
			<!-- wp:heading {"textColor":"blanco"} -->
			<h2 class="wp-block-heading has-blanco-color has-text-color">Los avisos del Ayuntamiento, directamente en tu móvil</h2>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"textColor":"verde-claro","fontSize":"large"} -->
			<p class="has-verde-claro-color has-text-color has-large-font-size">Entérate antes que nadie de bandos, cortes, averías, fiestas y actividades. Es gratis y nadie ve tu número de teléfono.</p>
			<!-- /wp:paragraph -->
			<!-- wp:list {"ordered":true,"className":"pasos"} -->
			<ol class="wp-block-list pasos">
				<!-- wp:list-item --><li>Abre el canal</li><!-- /wp:list-item -->
				<!-- wp:list-item --><li>Pulsa «Seguir»</li><!-- /wp:list-item -->
				<!-- wp:list-item --><li>Activa la campana de avisos</li><!-- /wp:list-item -->
			</ol>
			<!-- /wp:list -->
			<!-- wp:buttons -->
			<div class="wp-block-buttons"><!-- wp:button {"backgroundColor":"blanco","textColor":"whatsapp","className":"boton-canal","style":{"border":{"radius":"999px"}}} -->
			<div class="wp-block-button boton-canal"><a class="wp-block-button__link has-whatsapp-color has-blanco-background-color has-text-color has-background wp-element-button" href="<?php echo esc_url( $canal ); ?>" style="border-radius:999px">Unirme al canal →</a></div>
			<!-- /wp:button --></div>
			<!-- /wp:buttons -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column {"verticalAlignment":"center","width":"38%","className":"columna-qr"} -->
		<div class="wp-block-column is-vertically-aligned-center columna-qr" style="flex-basis:38%">
			<!-- wp:image {"width":"180px","sizeSlug":"full","align":"center","className":"qr","style":{"border":{"radius":"14px"}}} -->
			<figure class="wp-block-image aligncenter size-full is-resized qr has-custom-border"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/img/qr-whatsapp.svg' ) ); ?>" alt="Código QR para unirse al canal de WhatsApp del Ayuntamiento" style="border-radius:14px;width:180px"/><figcaption class="wp-element-caption">Escanéalo con la cámara del móvil</figcaption></figure>
			<!-- /wp:image -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
