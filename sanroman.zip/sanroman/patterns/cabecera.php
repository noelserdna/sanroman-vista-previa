<?php
/**
 * Title: Cabecera
 * Slug: sanroman/cabecera
 * Categories: header
 * Block Types: core/template-part/header
 * Inserter: no
 */

$url = static fn( $ruta ) => esc_url( home_url( $ruta ) );
?>
<!-- wp:group {"className":"barra-superior","style":{"spacing":{"padding":{"top":"0.5rem","bottom":"0.5rem"}}},"backgroundColor":"pizarra","textColor":"granito","fontSize":"small","layout":{"type":"constrained"}} -->
<div class="wp-block-group barra-superior has-granito-color has-pizarra-background-color has-text-color has-background has-small-font-size" style="padding-top:0.5rem;padding-bottom:0.5rem">
	<!-- wp:group {"align":"wide","layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between"}} -->
	<div class="wp-block-group alignwide">
		<!-- wp:paragraph -->
		<p>Plaza Constitución, 3 · 45646 San Román de los Montes (Toledo) · Lunes a viernes, 9:00–14:00</p>
		<!-- /wp:paragraph -->
		<!-- wp:paragraph -->
		<p><a href="tel:+34925887002"><strong>925 88 70 02</strong></a> · <a href="https://whatsapp.com/channel/0029VaTsvKSGzzKPsiTUxa1b">Canal de WhatsApp</a></p>
		<!-- /wp:paragraph -->
	</div>
	<!-- /wp:group -->
</div>
<!-- /wp:group -->

<!-- wp:group {"tagName":"header","className":"cabecera","style":{"spacing":{"padding":{"top":"1rem","bottom":"1rem"}},"border":{"bottom":{"color":"var:preset|color|linea","width":"1px"}}},"backgroundColor":"blanco","layout":{"type":"constrained"}} -->
<header class="wp-block-group cabecera has-blanco-background-color has-background" style="border-bottom-color:var(--wp--preset--color--linea);border-bottom-width:1px;padding-top:1rem;padding-bottom:1rem">
	<!-- wp:group {"align":"wide","layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between","verticalAlignment":"center"},"style":{"spacing":{"blockGap":"1rem 2rem"}}} -->
	<div class="wp-block-group alignwide">
		<!-- wp:image {"width":"212px","sizeSlug":"full","linkDestination":"custom","className":"escudo","style":{"border":{"radius":"0px"}}} -->
		<figure class="wp-block-image size-full is-resized escudo has-custom-border"><a href="<?php echo $url( '/' ); ?>"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/escudo.png' ) ); ?>" alt="Ayuntamiento de San Román de los Montes, inicio" style="border-radius:0px;width:212px"/></a></figure>
		<!-- /wp:image -->

		<!-- wp:navigation {"overlayMenu":"mobile","openSubmenusOnClick":true,"layout":{"type":"flex","justifyContent":"right"},"style":{"spacing":{"blockGap":"1.75rem"}}} -->
			<!-- wp:navigation-submenu {"label":"Municipio","url":"<?php echo $url( '/datos-generales/' ); ?>","kind":"custom"} -->
				<!-- wp:navigation-link {"label":"Datos generales","url":"<?php echo $url( '/datos-generales/' ); ?>","kind":"custom"} /-->
				<!-- wp:navigation-link {"label":"Historia","url":"<?php echo $url( '/historia/' ); ?>","kind":"custom"} /-->
				<!-- wp:navigation-link {"label":"Fiestas patronales","url":"<?php echo $url( '/fiestas-patronales/' ); ?>","kind":"custom"} /-->
				<!-- wp:navigation-link {"label":"Urbanización Reguerones","url":"https://reguerones.web.app/","kind":"custom"} /-->
			<!-- /wp:navigation-submenu -->
			<!-- wp:navigation-submenu {"label":"Ayuntamiento","url":"<?php echo $url( '/saludo-del-alcalde/' ); ?>","kind":"custom"} -->
				<!-- wp:navigation-link {"label":"Saludo de la alcaldesa","url":"<?php echo $url( '/saludo-del-alcalde/' ); ?>","kind":"custom"} /-->
				<!-- wp:navigation-link {"label":"Corporación municipal","url":"<?php echo $url( '/corporacion-municipal/' ); ?>","kind":"custom"} /-->
				<!-- wp:navigation-link {"label":"Empresas","url":"<?php echo $url( '/empresas/' ); ?>","kind":"custom"} /-->
				<!-- wp:navigation-link {"label":"Vecinos destacados","url":"<?php echo $url( '/vecinos-destacados-2/' ); ?>","kind":"custom"} /-->
			<!-- /wp:navigation-submenu -->
			<!-- wp:navigation-submenu {"label":"Servicios","url":"<?php echo $url( '/telefonos-de-interes/' ); ?>","kind":"custom"} -->
				<!-- wp:navigation-link {"label":"Teléfonos de interés","url":"<?php echo $url( '/telefonos-de-interes/' ); ?>","kind":"custom"} /-->
				<!-- wp:navigation-link {"label":"Reserva de pistas","url":"https://reservadeportes.com/AytoSanromandelosmontes.html","kind":"custom"} /-->
				<!-- wp:navigation-link {"label":"Producción solar","url":"https://solar-web-dashboard.andresleontest.workers.dev/dashboard-accesible","kind":"custom"} /-->
				<!-- wp:navigation-link {"label":"Sede electrónica","url":"https://sanromandelosmontes.sedelectronica.es/","kind":"custom"} /-->
			<!-- /wp:navigation-submenu -->
			<!-- wp:navigation-link {"label":"Noticias","url":"<?php echo $url( '/noticias/' ); ?>","kind":"custom"} /-->
			<!-- wp:navigation-link {"label":"Avisos","url":"<?php echo $url( '/avisos-y-bandos/' ); ?>","kind":"custom"} /-->
			<!-- wp:navigation-link {"label":"Contacto","url":"<?php echo $url( '/contacto/' ); ?>","kind":"custom"} /-->
		<!-- /wp:navigation -->

		<!-- wp:buttons {"className":"boton-sede"} -->
		<div class="wp-block-buttons boton-sede"><!-- wp:button -->
		<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="https://sanromandelosmontes.sedelectronica.es/">Sede electrónica</a></div>
		<!-- /wp:button --></div>
		<!-- /wp:buttons -->
	</div>
	<!-- /wp:group -->
</header>
<!-- /wp:group -->
