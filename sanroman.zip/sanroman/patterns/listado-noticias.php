<?php
/**
 * Title: Listado de noticias
 * Slug: sanroman/listado-noticias
 * Categories: sanroman
 * Inserter: no
 * Description: Filtros por tema, rejilla de noticias y paginación (página de noticias y archivos).
 */
?>
<!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|60"}}},"layout":{"type":"default"}} -->
<div class="wp-block-group alignwide" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--60)">
	<!-- wp:group {"className":"filtros-noticias","layout":{"type":"flex","flexWrap":"wrap"},"style":{"spacing":{"blockGap":"0.5rem"}}} -->
	<div class="wp-block-group filtros-noticias">
		<!-- wp:buttons -->
		<div class="wp-block-buttons"><!-- wp:button {"className":"is-style-pildora"} -->
		<div class="wp-block-button is-style-pildora"><a class="wp-block-button__link wp-element-button" href="<?php echo esc_url( home_url( '/noticias/' ) ); ?>">Todas</a></div>
		<!-- /wp:button --></div>
		<!-- /wp:buttons -->
		<!-- wp:categories {"className":"is-style-filtros","showEmpty":false} /-->
	</div>
	<!-- /wp:group -->

	<!-- wp:query {"queryId":41,"query":{"inherit":true,"perPage":9},"className":"rejilla-noticias","style":{"spacing":{"margin":{"top":"var:preset|spacing|40"}}}} -->
	<div class="wp-block-query rejilla-noticias" style="margin-top:var(--wp--preset--spacing--40)">
		<!-- wp:post-template {"layout":{"type":"grid","minimumColumnWidth":"18rem"},"style":{"spacing":{"blockGap":"1.25rem"}}} -->
			<!-- wp:group {"className":"is-style-tarjeta tarjeta-noticia","style":{"spacing":{"padding":{"top":"0","bottom":"1.375rem","left":"0","right":"0"},"blockGap":"0.5rem"}},"layout":{"type":"default"}} -->
			<div class="wp-block-group is-style-tarjeta tarjeta-noticia" style="padding-top:0;padding-right:0;padding-bottom:1.375rem;padding-left:0">
				<!-- wp:post-featured-image {"isLink":true,"aspectRatio":"16/10","style":{"border":{"radius":"0px"}}} /-->
				<!-- wp:group {"className":"tarjeta-noticia__meta","layout":{"type":"flex","flexWrap":"wrap"},"style":{"spacing":{"blockGap":"0.625rem"}}} -->
				<div class="wp-block-group tarjeta-noticia__meta">
					<!-- wp:post-terms {"term":"category","className":"etiqueta-categoria"} /-->
					<!-- wp:post-date {"format":"j M Y"} /-->
				</div>
				<!-- /wp:group -->
				<!-- wp:post-title {"level":2,"isLink":true,"className":"tarjeta-noticia__titulo","fontSize":"large"} /-->
				<!-- wp:post-excerpt {"excerptLength":20,"className":"tarjeta-noticia__texto","textColor":"gris","fontSize":"small"} /-->
			</div>
			<!-- /wp:group -->
		<!-- /wp:post-template -->

		<!-- wp:query-pagination {"layout":{"type":"flex","justifyContent":"center"},"style":{"spacing":{"margin":{"top":"var:preset|spacing|50"}}}} -->
			<!-- wp:query-pagination-previous {"label":"Anteriores"} /-->
			<!-- wp:query-pagination-numbers /-->
			<!-- wp:query-pagination-next {"label":"Siguientes"} /-->
		<!-- /wp:query-pagination -->

		<!-- wp:query-no-results -->
			<!-- wp:paragraph {"textColor":"gris"} -->
			<p class="has-gris-color has-text-color">Todavía no hay noticias en esta sección.</p>
			<!-- /wp:paragraph -->
		<!-- /wp:query-no-results -->
	</div>
	<!-- /wp:query -->

	<!-- wp:pattern {"slug":"sanroman/aviso-whatsapp"} /-->
</div>
<!-- /wp:group -->
