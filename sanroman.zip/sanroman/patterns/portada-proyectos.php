<?php
/**
 * Title: Proyectos cofinanciados (carteles oficiales)
 * Slug: sanroman/portada-proyectos
 * Categories: sanroman-portada, sanroman
 * Description: Carteles de publicidad obligatoria de las subvenciones, con su descripción en texto.
 */

$subidas = 'https://sanromandelosmontes.org/wp-content/uploads';
?>
<!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|60"}}},"layout":{"type":"default"}} -->
<div class="wp-block-group alignwide" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--60)">
	<!-- wp:heading -->
	<h2 class="wp-block-heading">Proyectos cofinanciados</h2>
	<!-- /wp:heading -->
	<!-- wp:paragraph {"textColor":"gris"} -->
	<p class="has-gris-color has-text-color">Actuaciones del Ayuntamiento financiadas con fondos europeos, estatales y autonómicos.</p>
	<!-- /wp:paragraph -->

	<!-- wp:group {"layout":{"type":"grid","minimumColumnWidth":"20rem"},"style":{"spacing":{"blockGap":"1.5rem"}}} -->
	<div class="wp-block-group">
		<!-- wp:group {"className":"is-style-tarjeta cartel","style":{"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"},"blockGap":"0"}},"layout":{"type":"default"}} -->
		<div class="wp-block-group is-style-tarjeta cartel" style="padding-top:0;padding-right:0;padding-bottom:0;padding-left:0">
			<!-- wp:image {"sizeSlug":"full","style":{"border":{"radius":"0px"}}} -->
			<figure class="wp-block-image size-full has-custom-border"><img src="<?php echo esc_url( $subidas . '/2026/10/Captura-de-pantalla-2026-10-19-a-las-9.23.52.png' ); ?>" alt="Cartel oficial del Programa de Apoyo Activo al Empleo 2026 de Castilla-La Mancha, cofinanciado por la Unión Europea" style="border-radius:0px"/></figure>
			<!-- /wp:image -->
			<!-- wp:paragraph {"className":"cartel__texto","fontSize":"small"} -->
			<p class="cartel__texto has-small-font-size"><strong>Programa de Apoyo Activo al Empleo 2026</strong><br>Mantenimiento de edificios, vías públicas, jardines y medio ambiente. Junta de Castilla-La Mancha y FSE+.</p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:group -->

		<!-- wp:group {"className":"is-style-tarjeta cartel","style":{"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"},"blockGap":"0"}},"layout":{"type":"default"}} -->
		<div class="wp-block-group is-style-tarjeta cartel" style="padding-top:0;padding-right:0;padding-bottom:0;padding-left:0">
			<!-- wp:image {"sizeSlug":"full","style":{"border":{"radius":"0px"}}} -->
			<figure class="wp-block-image size-full has-custom-border"><img src="<?php echo esc_url( $subidas . '/2022/04/san-roman-de-los-montes-ayuda-proyecto-pemis.jpg' ); ?>" alt="Cartel oficial del Proyecto PEMIS de renovación del alumbrado exterior, cofinanciado por el FEDER y gestionado por el IDAE" style="border-radius:0px"/></figure>
			<!-- /wp:image -->
			<!-- wp:paragraph {"className":"cartel__texto","fontSize":"small"} -->
			<p class="cartel__texto has-small-font-size"><strong>Renovación del alumbrado exterior (PEMIS)</strong><br>Inversión total 897.262,00 € · ayuda 717.809,60 €. FEDER e IDAE.</p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:group -->

		<!-- wp:group {"className":"is-style-tarjeta cartel","style":{"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"},"blockGap":"0"}},"layout":{"type":"default"}} -->
		<div class="wp-block-group is-style-tarjeta cartel" style="padding-top:0;padding-right:0;padding-bottom:0;padding-left:0">
			<!-- wp:image {"sizeSlug":"full","linkDestination":"custom","style":{"border":{"radius":"0px"}}} -->
			<figure class="wp-block-image size-full has-custom-border"><a href="<?php echo esc_url( $subidas . '/2026/03/20251127_Otros_20250730_Otros_Modelo_2._Acuerdo_de_Reparto_de_energia-1.pdf' ); ?>"><img src="<?php echo esc_url( $subidas . '/2025/04/cartelDUS5000.png' ); ?>" alt="Cartel oficial del Proyecto PEMIS de autoconsumo solar fotovoltaico, financiado por NextGenerationEU, programa DUS 5000. Abre el acuerdo de reparto de energía en PDF" style="border-radius:0px"/></a></figure>
			<!-- /wp:image -->
			<!-- wp:paragraph {"className":"cartel__texto","fontSize":"small"} -->
			<p class="cartel__texto has-small-font-size"><strong>Autoconsumo solar fotovoltaico (DUS 5000)</strong><br>Inversión total 74.582,10 €. NextGenerationEU. <a href="<?php echo esc_url( $subidas . '/2026/03/20251127_Otros_20250730_Otros_Modelo_2._Acuerdo_de_Reparto_de_energia-1.pdf' ); ?>">Acuerdo de reparto de energía (PDF)</a></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:group -->
	</div>
	<!-- /wp:group -->
</div>
<!-- /wp:group -->
