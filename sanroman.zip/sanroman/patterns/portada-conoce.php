<?php
/**
 * Title: Portada · Conoce San Román
 * Slug: sanroman/portada-conoce
 * Categories: sanroman-portada
 * Description: Tres fichas con foto que llevan a Historia, Fiestas y Datos generales.
 */
?>
<!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"layout":{"type":"default"}} -->
<div class="wp-block-group alignwide" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)">
	<!-- wp:heading -->
	<h2 class="wp-block-heading">Conoce San Román</h2>
	<!-- /wp:heading -->
	<!-- wp:paragraph {"textColor":"gris"} -->
	<p class="has-gris-color has-text-color">Un pueblo de la Sierra de San Vicente, a 15 km de Talavera de la Reina, con vistas al monte y al pantano. Ya somos 2.191 vecinos.</p>
	<!-- /wp:paragraph -->
	<!-- wp:group {"layout":{"type":"grid","minimumColumnWidth":"18rem"},"style":{"spacing":{"blockGap":"1.5rem"}}} -->
	<div class="wp-block-group">
		<!-- wp:group {"className":"is-style-tarjeta ficha-foto","style":{"spacing":{"padding":{"top":"0","bottom":"1.375rem","left":"0","right":"0"},"blockGap":"0.5rem"}},"layout":{"type":"default"}} -->
		<div class="wp-block-group is-style-tarjeta ficha-foto" style="padding-top:0;padding-right:0;padding-bottom:1.375rem;padding-left:0">
			<!-- wp:image {"aspectRatio":"4/3","scale":"cover","sizeSlug":"full","style":{"border":{"radius":"0px"}}} -->
			<figure class="wp-block-image size-full has-custom-border"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/img/casona.jpg' ) ); ?>" alt="Casona con escudo en la fachada" style="border-radius:0px;aspect-ratio:4/3;object-fit:cover"/></figure>
			<!-- /wp:image -->
			<!-- wp:heading {"level":3,"className":"ficha-foto__titulo","fontSize":"x-large"} -->
			<h3 class="wp-block-heading ficha-foto__titulo has-x-large-font-size"><a href="<?php echo esc_url( home_url( '/historia/' ) ); ?>">Historia</a></h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"className":"ficha-foto__texto","textColor":"gris","fontSize":"small"} -->
			<p class="ficha-foto__texto has-gris-color has-text-color has-small-font-size">Del rollo jurisdiccional al sarcófago del siglo XI: el patrimonio del municipio.</p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:group -->

		<!-- wp:group {"className":"is-style-tarjeta ficha-foto","style":{"spacing":{"padding":{"top":"0","bottom":"1.375rem","left":"0","right":"0"},"blockGap":"0.5rem"}},"layout":{"type":"default"}} -->
		<div class="wp-block-group is-style-tarjeta ficha-foto" style="padding-top:0;padding-right:0;padding-bottom:1.375rem;padding-left:0">
			<!-- wp:image {"aspectRatio":"4/3","scale":"cover","sizeSlug":"full","style":{"border":{"radius":"0px"}}} -->
			<figure class="wp-block-image size-full has-custom-border"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/img/ermita.jpg' ) ); ?>" alt="Ermita de la Virgen del Buen Camino" style="border-radius:0px;aspect-ratio:4/3;object-fit:cover"/></figure>
			<!-- /wp:image -->
			<!-- wp:heading {"level":3,"className":"ficha-foto__titulo","fontSize":"x-large"} -->
			<h3 class="wp-block-heading ficha-foto__titulo has-x-large-font-size"><a href="<?php echo esc_url( home_url( '/fiestas-patronales/' ) ); ?>">Fiestas patronales</a></h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"className":"ficha-foto__texto","textColor":"gris","fontSize":"small"} -->
			<p class="ficha-foto__texto has-gris-color has-text-color has-small-font-size">La Virgen del Buen Camino, San Román y los Carnavales.</p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:group -->

		<!-- wp:group {"className":"is-style-tarjeta ficha-foto","style":{"spacing":{"padding":{"top":"0","bottom":"1.375rem","left":"0","right":"0"},"blockGap":"0.5rem"}},"layout":{"type":"default"}} -->
		<div class="wp-block-group is-style-tarjeta ficha-foto" style="padding-top:0;padding-right:0;padding-bottom:1.375rem;padding-left:0">
			<!-- wp:image {"aspectRatio":"4/3","scale":"cover","sizeSlug":"full","style":{"border":{"radius":"0px"}}} -->
			<figure class="wp-block-image size-full has-custom-border"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/img/piscina.jpg' ) ); ?>" alt="Piscina municipal" style="border-radius:0px;aspect-ratio:4/3;object-fit:cover"/></figure>
			<!-- /wp:image -->
			<!-- wp:heading {"level":3,"className":"ficha-foto__titulo","fontSize":"x-large"} -->
			<h3 class="wp-block-heading ficha-foto__titulo has-x-large-font-size"><a href="<?php echo esc_url( home_url( '/datos-generales/' ) ); ?>">Datos generales</a></h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"className":"ficha-foto__texto","textColor":"gris","fontSize":"small"} -->
			<p class="ficha-foto__texto has-gris-color has-text-color has-small-font-size">Situación, población, superficie e instalaciones municipales.</p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:group -->
	</div>
	<!-- /wp:group -->
</div>
<!-- /wp:group -->
