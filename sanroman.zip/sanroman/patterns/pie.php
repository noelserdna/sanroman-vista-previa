<?php
/**
 * Title: Pie
 * Slug: sanroman/pie
 * Categories: footer
 * Block Types: core/template-part/footer
 * Inserter: no
 */

$url = static fn( $ruta ) => esc_url( home_url( $ruta ) );
?>
<!-- wp:group {"tagName":"footer","className":"pie","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|40"},"margin":{"top":"0"}},"border":{"top":{"color":"var:preset|color|linea","width":"1px"}}},"backgroundColor":"granito","fontSize":"small","layout":{"type":"constrained"}} -->
<footer class="wp-block-group pie has-granito-background-color has-background has-small-font-size" style="border-top-color:var(--wp--preset--color--linea);border-top-width:1px;margin-top:0;padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--40)">
	<!-- wp:columns {"align":"wide","style":{"spacing":{"blockGap":{"left":"2rem"}}}} -->
	<div class="wp-block-columns alignwide">
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:image {"width":"190px","sizeSlug":"full","style":{"border":{"radius":"0px"}}} -->
			<figure class="wp-block-image size-full is-resized has-custom-border"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/escudo.png' ) ); ?>" alt="Ayuntamiento de San Román de los Montes" style="border-radius:0px;width:190px"/></figure>
			<!-- /wp:image -->
			<!-- wp:paragraph {"textColor":"gris"} -->
			<p class="has-gris-color has-text-color">Plaza Constitución, 3<br>45646 San Román de los Montes (Toledo)<br>CIF P-4515500-I</p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:heading {"level":2,"className":"titulo-pie"} -->
			<h2 class="wp-block-heading titulo-pie">Atención</h2>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"textColor":"gris"} -->
			<p class="has-gris-color has-text-color">Lunes a viernes, 9:00–14:00<br><a href="tel:+34925887002">925 88 70 02</a> · <a href="tel:+34925887115">925 88 71 15</a></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:heading {"level":2,"className":"titulo-pie"} -->
			<h2 class="wp-block-heading titulo-pie">Ayuntamiento</h2>
			<!-- /wp:heading -->
			<!-- wp:list {"className":"lista-pie"} -->
			<ul class="wp-block-list lista-pie">
				<!-- wp:list-item --><li><a href="<?php echo $url( '/saludo-del-alcalde/' ); ?>">Saludo de la alcaldesa</a></li><!-- /wp:list-item -->
				<!-- wp:list-item --><li><a href="<?php echo $url( '/corporacion-municipal/' ); ?>">Corporación municipal</a></li><!-- /wp:list-item -->
				<!-- wp:list-item --><li><a href="<?php echo $url( '/noticias/' ); ?>">Noticias</a></li><!-- /wp:list-item -->
				<!-- wp:list-item --><li><a href="<?php echo $url( '/avisos-y-bandos/' ); ?>">Avisos y bandos</a></li><!-- /wp:list-item -->
			</ul>
			<!-- /wp:list -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:heading {"level":2,"className":"titulo-pie"} -->
			<h2 class="wp-block-heading titulo-pie">Información legal</h2>
			<!-- /wp:heading -->
			<!-- wp:list {"className":"lista-pie"} -->
			<ul class="wp-block-list lista-pie">
				<!-- wp:list-item --><li><a href="https://sanromandelosmontes.sedelectronica.es/transparency/c0265a77-c08f-452f-a047-50ce905f402c/">Protección de datos</a></li><!-- /wp:list-item -->
				<!-- wp:list-item --><li><a href="<?php echo $url( '/aviso-legal-y-politica-de-privacidad/' ); ?>">Aviso legal</a></li><!-- /wp:list-item -->
				<!-- wp:list-item --><li><a href="<?php echo $url( '/accesibilidad/' ); ?>">Declaración de accesibilidad</a></li><!-- /wp:list-item -->
				<!-- wp:list-item --><li><a href="https://sanromandelosmontes.sedelectronica.es/">Sede electrónica</a></li><!-- /wp:list-item -->
			</ul>
			<!-- /wp:list -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->

	<!-- wp:paragraph {"align":"wide","className":"creditos","textColor":"gris","fontSize":"x-small"} -->
	<p class="alignwide creditos has-gris-color has-text-color has-x-small-font-size">© <?php echo esc_html( gmdate( 'Y' ) ); ?> Excmo. Ayuntamiento de San Román de los Montes</p>
	<!-- /wp:paragraph -->
</footer>
<!-- /wp:group -->
