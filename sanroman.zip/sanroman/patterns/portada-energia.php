<?php
/**
 * Title: Energía municipal
 * Slug: sanroman/portada-energia
 * Categories: sanroman-portada, sanroman
 * Description: Franja verde con un sol simpático que enlaza con la producción solar en tiempo real.
 */
?>
<!-- wp:group {"align":"full","className":"franja-energia","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"backgroundColor":"pinar","textColor":"blanco","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull franja-energia has-blanco-color has-pinar-background-color has-text-color has-background" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)">
	<!-- wp:columns {"verticalAlignment":"center","align":"wide","style":{"spacing":{"blockGap":{"left":"3rem"}}}} -->
	<div class="wp-block-columns alignwide are-vertically-aligned-center">
		<!-- wp:column {"verticalAlignment":"center","width":"24%","className":"columna-sol"} -->
		<div class="wp-block-column is-vertically-aligned-center columna-sol" style="flex-basis:24%">
			<!-- wp:image {"width":"220px","sizeSlug":"full","align":"center","className":"sol","style":{"border":{"radius":"0px"}}} -->
			<figure class="wp-block-image aligncenter size-full is-resized sol has-custom-border"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/img/sol.svg' ) ); ?>" alt="" style="border-radius:0px;width:220px"/></figure>
			<!-- /wp:image -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column {"verticalAlignment":"center","width":"50%"} -->
		<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:50%">
			<!-- wp:paragraph {"className":"antetitulo antetitulo--claro"} -->
			<p class="antetitulo antetitulo--claro">Energía municipal</p>
			<!-- /wp:paragraph -->
			<!-- wp:heading {"textColor":"blanco"} -->
			<h2 class="wp-block-heading has-blanco-color has-text-color">El sol de San Román ya alimenta nuestros edificios</h2>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"textColor":"verde-claro"} -->
			<p class="has-verde-claro-color has-text-color">Las placas del proyecto de autoconsumo solar producen electricidad para los servicios municipales. Consulta la producción en directo y los datos históricos.</p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column {"verticalAlignment":"center","width":"26%"} -->
		<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:26%">
			<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"right"}} -->
			<div class="wp-block-buttons"><!-- wp:button {"backgroundColor":"blanco","textColor":"pinar"} -->
			<div class="wp-block-button"><a class="wp-block-button__link has-pinar-color has-blanco-background-color has-text-color has-background wp-element-button" href="https://solar-web-dashboard.andresleontest.workers.dev/dashboard-accesible">Ver producción en tiempo real</a></div>
			<!-- /wp:button --></div>
			<!-- /wp:buttons -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
