<?php
/**
 * Title: Teléfonos urgentes
 * Slug: sanroman/portada-urgencias
 * Categories: sanroman-portada, sanroman
 * Description: Franja oscura con los teléfonos de urgencia, que se pueden tocar para llamar.
 */
?>
<!-- wp:group {"align":"wide","className":"urgencias","style":{"spacing":{"padding":{"top":"1.125rem","bottom":"1.125rem","left":"1.5rem","right":"1.5rem"},"blockGap":"0.75rem 2rem","margin":{"top":"var:preset|spacing|40"}},"border":{"radius":"10px"}},"backgroundColor":"pizarra","textColor":"blanco","layout":{"type":"flex","flexWrap":"wrap","verticalAlignment":"center"}} -->
<div class="wp-block-group alignwide urgencias has-blanco-color has-pizarra-background-color has-text-color has-background" style="border-radius:10px;margin-top:var(--wp--preset--spacing--40);padding-top:1.125rem;padding-right:1.5rem;padding-bottom:1.125rem;padding-left:1.5rem">
	<!-- wp:paragraph {"className":"urgencias__titulo"} -->
	<p class="urgencias__titulo">Urgencias</p>
	<!-- /wp:paragraph -->
	<!-- wp:paragraph -->
	<p><a href="tel:112"><span>Emergencias</span> <strong>112</strong></a></p>
	<!-- /wp:paragraph -->
	<!-- wp:paragraph -->
	<p><a href="tel:+34690857355"><span>Averías (guardia)</span> <strong>690 857 355</strong></a></p>
	<!-- /wp:paragraph -->
	<!-- wp:paragraph -->
	<p><a href="tel:+34925862191"><span>Cita médica</span> <strong>925 86 21 91</strong></a></p>
	<!-- /wp:paragraph -->
	<!-- wp:paragraph -->
	<p><a href="tel:062"><span>Guardia Civil</span> <strong>062</strong></a></p>
	<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
