<?php
/**
 * Title: Portada · Accesos rápidos
 * Slug: sanroman/portada-accesos
 * Categories: sanroman-portada
 * Description: Tarjetas con los servicios más usados. Toda la tarjeta es clicable.
 */
?>
<!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"var:preset|spacing|50"}}},"layout":{"type":"default"}} -->
<div class="wp-block-group alignwide" style="padding-top:var(--wp--preset--spacing--50)">
	<!-- wp:heading -->
	<h2 class="wp-block-heading">Accesos rápidos</h2>
	<!-- /wp:heading -->
	<!-- wp:group {"className":"rejilla-accesos","layout":{"type":"grid","minimumColumnWidth":"22rem"},"style":{"spacing":{"blockGap":"1rem"}}} -->
	<div class="wp-block-group rejilla-accesos">
		<!-- wp:group {"className":"is-style-tarjeta acceso","layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"top"}} -->
		<div class="wp-block-group is-style-tarjeta acceso">
			<!-- wp:image {"width":"48px","sizeSlug":"full","className":"icono","style":{"border":{"radius":"10px"}}} -->
			<figure class="wp-block-image size-full is-resized icono has-custom-border"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/iconos/sede.svg' ) ); ?>" alt="" style="border-radius:10px;width:48px"/></figure>
			<!-- /wp:image -->
			<!-- wp:group {"layout":{"type":"flex","orientation":"vertical"},"style":{"spacing":{"blockGap":"0.25rem"}}} -->
			<div class="wp-block-group">
				<!-- wp:heading {"level":3,"fontSize":"large"} -->
				<h3 class="wp-block-heading has-large-font-size"><a href="https://sanromandelosmontes.sedelectronica.es/">Sede electrónica</a></h3>
				<!-- /wp:heading -->
				<!-- wp:paragraph {"textColor":"gris","fontSize":"small"} -->
				<p class="has-gris-color has-text-color has-small-font-size">Registro, certificados, padrón y tasas sin desplazarte.</p>
				<!-- /wp:paragraph -->
			</div>
			<!-- /wp:group -->
		</div>
		<!-- /wp:group -->

		<!-- wp:group {"className":"is-style-tarjeta acceso","layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"top"}} -->
		<div class="wp-block-group is-style-tarjeta acceso">
			<!-- wp:image {"width":"48px","sizeSlug":"full","className":"icono","style":{"border":{"radius":"10px"}}} -->
			<figure class="wp-block-image size-full is-resized icono has-custom-border"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/iconos/reservas.svg' ) ); ?>" alt="" style="border-radius:10px;width:48px"/></figure>
			<!-- /wp:image -->
			<!-- wp:group {"layout":{"type":"flex","orientation":"vertical"},"style":{"spacing":{"blockGap":"0.25rem"}}} -->
			<div class="wp-block-group">
				<!-- wp:heading {"level":3,"fontSize":"large"} -->
				<h3 class="wp-block-heading has-large-font-size"><a href="https://reservadeportes.com/AytoSanromandelosmontes.html">Reserva de pistas</a></h3>
				<!-- /wp:heading -->
				<!-- wp:paragraph {"textColor":"gris","fontSize":"small"} -->
				<p class="has-gris-color has-text-color has-small-font-size">Pádel y pistas municipales, reserva y paga en línea.</p>
				<!-- /wp:paragraph -->
			</div>
			<!-- /wp:group -->
		</div>
		<!-- /wp:group -->

		<!-- wp:group {"className":"is-style-tarjeta acceso","layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"top"}} -->
		<div class="wp-block-group is-style-tarjeta acceso">
			<!-- wp:image {"width":"48px","sizeSlug":"full","className":"icono","style":{"border":{"radius":"10px"}}} -->
			<figure class="wp-block-image size-full is-resized icono has-custom-border"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/iconos/cita.svg' ) ); ?>" alt="" style="border-radius:10px;width:48px"/></figure>
			<!-- /wp:image -->
			<!-- wp:group {"layout":{"type":"flex","orientation":"vertical"},"style":{"spacing":{"blockGap":"0.25rem"}}} -->
			<div class="wp-block-group">
				<!-- wp:heading {"level":3,"fontSize":"large"} -->
				<h3 class="wp-block-heading has-large-font-size"><a href="<?php echo esc_url( home_url( '/contacto/' ) ); ?>">Cita previa</a></h3>
				<!-- /wp:heading -->
				<!-- wp:paragraph {"textColor":"gris","fontSize":"small"} -->
				<p class="has-gris-color has-text-color has-small-font-size">La atención presencial en el Ayuntamiento es con cita.</p>
				<!-- /wp:paragraph -->
			</div>
			<!-- /wp:group -->
		</div>
		<!-- /wp:group -->

		<!-- wp:group {"className":"is-style-tarjeta acceso","layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"top"}} -->
		<div class="wp-block-group is-style-tarjeta acceso">
			<!-- wp:image {"width":"48px","sizeSlug":"full","className":"icono","style":{"border":{"radius":"10px"}}} -->
			<figure class="wp-block-image size-full is-resized icono has-custom-border"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/iconos/telefono.svg' ) ); ?>" alt="" style="border-radius:10px;width:48px"/></figure>
			<!-- /wp:image -->
			<!-- wp:group {"layout":{"type":"flex","orientation":"vertical"},"style":{"spacing":{"blockGap":"0.25rem"}}} -->
			<div class="wp-block-group">
				<!-- wp:heading {"level":3,"fontSize":"large"} -->
				<h3 class="wp-block-heading has-large-font-size"><a href="<?php echo esc_url( home_url( '/telefonos-de-interes/' ) ); ?>">Teléfonos de interés</a></h3>
				<!-- /wp:heading -->
				<!-- wp:paragraph {"textColor":"gris","fontSize":"small"} -->
				<p class="has-gris-color has-text-color has-small-font-size">Servicios, salud, asociaciones y urgencias.</p>
				<!-- /wp:paragraph -->
			</div>
			<!-- /wp:group -->
		</div>
		<!-- /wp:group -->

		<!-- wp:group {"className":"is-style-tarjeta acceso","layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"top"}} -->
		<div class="wp-block-group is-style-tarjeta acceso">
			<!-- wp:image {"width":"48px","sizeSlug":"full","className":"icono","style":{"border":{"radius":"10px"}}} -->
			<figure class="wp-block-image size-full is-resized icono has-custom-border"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/iconos/empresas.svg' ) ); ?>" alt="" style="border-radius:10px;width:48px"/></figure>
			<!-- /wp:image -->
			<!-- wp:group {"layout":{"type":"flex","orientation":"vertical"},"style":{"spacing":{"blockGap":"0.25rem"}}} -->
			<div class="wp-block-group">
				<!-- wp:heading {"level":3,"fontSize":"large"} -->
				<h3 class="wp-block-heading has-large-font-size"><a href="<?php echo esc_url( home_url( '/empresas/' ) ); ?>">Empresas</a></h3>
				<!-- /wp:heading -->
				<!-- wp:paragraph {"textColor":"gris","fontSize":"small"} -->
				<p class="has-gris-color has-text-color has-small-font-size">Comercios, bares y profesionales del municipio.</p>
				<!-- /wp:paragraph -->
			</div>
			<!-- /wp:group -->
		</div>
		<!-- /wp:group -->

		<!-- wp:group {"className":"is-style-tarjeta acceso","layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"top"}} -->
		<div class="wp-block-group is-style-tarjeta acceso">
			<!-- wp:image {"width":"48px","sizeSlug":"full","className":"icono","style":{"border":{"radius":"10px"}}} -->
			<figure class="wp-block-image size-full is-resized icono has-custom-border"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/iconos/urbanizacion.svg' ) ); ?>" alt="" style="border-radius:10px;width:48px"/></figure>
			<!-- /wp:image -->
			<!-- wp:group {"layout":{"type":"flex","orientation":"vertical"},"style":{"spacing":{"blockGap":"0.25rem"}}} -->
			<div class="wp-block-group">
				<!-- wp:heading {"level":3,"fontSize":"large"} -->
				<h3 class="wp-block-heading has-large-font-size"><a href="https://reguerones.web.app/">Reguerones</a></h3>
				<!-- /wp:heading -->
				<!-- wp:paragraph {"textColor":"gris","fontSize":"small"} -->
				<p class="has-gris-color has-text-color has-small-font-size">Información de la urbanización Reguerones.</p>
				<!-- /wp:paragraph -->
			</div>
			<!-- /wp:group -->
		</div>
		<!-- /wp:group -->
	</div>
	<!-- /wp:group -->
</div>
<!-- /wp:group -->
