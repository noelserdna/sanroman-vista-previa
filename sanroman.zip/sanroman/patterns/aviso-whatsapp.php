<?php
/**
 * Title: Recordatorio del canal de WhatsApp
 * Slug: sanroman/aviso-whatsapp
 * Categories: sanroman
 * Description: Caja verde compacta para el final de noticias y páginas.
 */
?>
<!-- wp:group {"className":"aviso-whatsapp","style":{"spacing":{"padding":{"top":"1.25rem","bottom":"1.25rem","left":"1.5rem","right":"1.5rem"},"margin":{"top":"var:preset|spacing|50"}},"border":{"radius":"12px"}},"backgroundColor":"whatsapp","textColor":"blanco","layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between","verticalAlignment":"center"}} -->
<div class="wp-block-group aviso-whatsapp has-blanco-color has-whatsapp-background-color has-text-color has-background" style="border-radius:12px;margin-top:var(--wp--preset--spacing--50);padding-top:1.25rem;padding-right:1.5rem;padding-bottom:1.25rem;padding-left:1.5rem">
	<!-- wp:paragraph {"textColor":"blanco"} -->
	<p class="has-blanco-color has-text-color"><strong>No te pierdas ninguna noticia.</strong> Cada novedad también se publica en el canal de WhatsApp del Ayuntamiento.</p>
	<!-- /wp:paragraph -->
	<!-- wp:buttons -->
	<div class="wp-block-buttons"><!-- wp:button {"backgroundColor":"blanco","textColor":"whatsapp","style":{"border":{"radius":"999px"}}} -->
	<div class="wp-block-button"><a class="wp-block-button__link has-whatsapp-color has-blanco-background-color has-text-color has-background wp-element-button" href="https://whatsapp.com/channel/0029VaTsvKSGzzKPsiTUxa1b" style="border-radius:999px">Unirme al canal</a></div>
	<!-- /wp:button --></div>
	<!-- /wp:buttons -->
</div>
<!-- /wp:group -->
