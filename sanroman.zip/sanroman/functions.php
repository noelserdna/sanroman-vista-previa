<?php
/**
 * Tema San Román de los Montes.
 */

require_once __DIR__ . '/inc/bandomovil.php';

add_action( 'after_setup_theme', function () {
	add_editor_style( 'style.css' );
	add_theme_support( 'post-thumbnails' );
} );

add_action( 'wp_enqueue_scripts', function () {
	wp_enqueue_style( 'sanroman', get_stylesheet_uri(), array(), wp_get_theme()->get( 'Version' ) );
} );

add_action( 'init', function () {
	register_block_type( __DIR__ . '/blocks/bandomovil' );

	register_block_pattern_category( 'sanroman-portada', array( 'label' => 'San Román · Portada' ) );
	register_block_pattern_category( 'sanroman', array( 'label' => 'San Román · Contenido' ) );

	// Tarjeta con borde: para accesos rápidos y fichas.
	register_block_style( 'core/group', array( 'name' => 'tarjeta', 'label' => 'Tarjeta' ) );
	// Botón tipo píldora para etiquetas y filtros.
	register_block_style( 'core/button', array( 'name' => 'pildora', 'label' => 'Píldora' ) );
	// Lista de categorías como filtros.
	register_block_style( 'core/categories', array( 'name' => 'filtros', 'label' => 'Filtros' ) );
} );

/**
 * Rellena la página de portada con las secciones del tema, como bloques editables.
 *
 * Solo actúa si la portada está vacía o solo contiene referencias a patrones,
 * para no pisar nunca lo que el Ayuntamiento haya editado.
 */
function sanroman_preparar_portada() {
	$id = (int) get_option( 'page_on_front' );
	if ( 'page' !== get_option( 'show_on_front' ) || ! $id ) {
		return;
	}
	$actual = trim( preg_replace( '/<!-- wp:pattern \{[^}]*\} \/-->/', '', (string) get_post_field( 'post_content', $id ) ) );
	if ( '' !== $actual ) {
		return;
	}
	$secciones = array( 'bienvenida', 'accesos', 'urgencias', 'avisos', 'whatsapp', 'noticias', 'proyectos', 'energia', 'conoce', 'saludo' );
	$registro  = WP_Block_Patterns_Registry::get_instance();
	$bloques   = array();
	foreach ( $secciones as $seccion ) {
		$patron = $registro->get_registered( 'sanroman/portada-' . $seccion );
		if ( $patron ) {
			$bloques[] = trim( $patron['content'] );
		}
	}
	wp_update_post( array( 'ID' => $id, 'post_content' => implode( "\n\n", $bloques ) ) );
}
add_action( 'after_switch_theme', function () {
	// Los patrones del tema se registran en «init»: se espera a que estén.
	did_action( 'init' ) ? sanroman_preparar_portada() : add_action( 'init', 'sanroman_preparar_portada', 20 );
} );

// El editor abre páginas y noticias con la cabecera y el pie visibles (bloqueados),
// para que se vea igual que la web y no solo el título.
add_action( 'init', function () {
	foreach ( array( 'page', 'post' ) as $tipo ) {
		add_post_type_support( $tipo, 'editor', array( 'default-mode' => 'template-locked' ) );
	}
} );

// Sin emojis de WordPress: una petición menos y nada de terceros.
remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
remove_action( 'wp_print_styles', 'print_emoji_styles' );
