<?php
/**
 * Lectura de avisos y bandos publicados en Bandomóvil.
 *
 * Bandomóvil no ofrece RSS ni API: se lee su página pública, se guarda en caché
 * 30 minutos y se conserva la última lectura correcta por si su web falla.
 */

const SANROMAN_BANDOMOVIL_URL = 'https://www.bandomovil.com/sanromandelosmontes';
const SANROMAN_BANDOMOVIL_APP = 'https://play.google.com/store/apps/details?id=es.bandomovil.sanromandelosmontes.informa';

/**
 * Devuelve los avisos más recientes.
 *
 * @return array<int, array{titulo:string, fecha:string, iso:string, categoria:string, enlace:string, adjunto:string}>
 */
function sanroman_bandomovil_avisos() {
	$avisos = get_transient( 'sanroman_bandomovil' );
	if ( false !== $avisos ) {
		return $avisos;
	}

	$respuesta = wp_remote_get( SANROMAN_BANDOMOVIL_URL, array( 'timeout' => 8 ) );
	$avisos    = array();
	if ( ! is_wp_error( $respuesta ) && 200 === wp_remote_retrieve_response_code( $respuesta ) ) {
		$avisos = sanroman_bandomovil_leer( wp_remote_retrieve_body( $respuesta ) );
	}

	if ( $avisos ) {
		update_option( 'sanroman_bandomovil_ultimo', $avisos, false );
		set_transient( 'sanroman_bandomovil', $avisos, 30 * MINUTE_IN_SECONDS );
		return $avisos;
	}

	// Bandomóvil no responde o ha cambiado su página: se reintenta en 5 minutos.
	$avisos = get_option( 'sanroman_bandomovil_ultimo', array() );
	set_transient( 'sanroman_bandomovil', $avisos, 5 * MINUTE_IN_SECONDS );
	return $avisos;
}

/**
 * Extrae los avisos del HTML de la página de Bandomóvil.
 */
function sanroman_bandomovil_leer( $html ) {
	$doc = new DOMDocument();
	libxml_use_internal_errors( true );
	$doc->loadHTML( '<?xml encoding="utf-8"?>' . $html );
	libxml_clear_errors();
	$xpath = new DOMXPath( $doc );

	$avisos = array();
	foreach ( $xpath->query( "//ul[contains(@class,'post-list')]/li" ) as $li ) {
		$titulo = trim( $xpath->evaluate( 'string(.//h3)', $li ) );
		if ( '' === $titulo ) {
			continue;
		}
		$fecha    = trim( $xpath->evaluate( "string(.//*[contains(@class,'post-publication')])", $li ) );
		$enlace   = $xpath->evaluate( 'string(.//a[1]/@href)', $li );
		$adjuntos = $xpath->query( ".//ul[contains(@class,'adjuntos')]//a/@href", $li );

		$avisos[] = array(
			'titulo'    => sanroman_bandomovil_titulo( $titulo ),
			'fecha'     => $fecha,
			'iso'       => sanroman_bandomovil_fecha_iso( $fecha ),
			'categoria' => trim( $xpath->evaluate( "string(.//span[contains(@class,'badge')])", $li ) ),
			'enlace'    => $enlace ? 'https://www.bandomovil.com' . $enlace : SANROMAN_BANDOMOVIL_URL,
			'adjunto'   => $adjuntos->length ? $adjuntos->item( 0 )->nodeValue : '',
		);
	}
	return $avisos;
}

/**
 * Los títulos llegan muchas veces en mayúsculas: se pasan a frase.
 */
function sanroman_bandomovil_titulo( $titulo ) {
	$letras = preg_replace( '/[^\p{L}]/u', '', $titulo );
	if ( $letras && mb_strtoupper( $letras ) === $letras ) {
		$titulo = mb_strtoupper( mb_substr( $titulo, 0, 1 ) ) . mb_strtolower( mb_substr( $titulo, 1 ) );
	}
	return $titulo;
}

/**
 * Convierte «09-Octubre-2026 14:33» en «2026-10-09».
 */
function sanroman_bandomovil_fecha_iso( $fecha ) {
	$meses = array( 'enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre' );
	if ( ! preg_match( '/(\d{1,2})-(\p{L}+)-(\d{4})/u', $fecha, $m ) ) {
		return '';
	}
	$mes = array_search( mb_strtolower( $m[2] ), $meses, true );
	return false === $mes ? '' : sprintf( '%04d-%02d-%02d', $m[3], $mes + 1, $m[1] );
}
