<?php
/**
 * Plugin Name: Aviso de vista previa
 * Description: Franja que indica que esta web es una maqueta de diseño, no la web oficial.
 */
add_action( 'wp_body_open', function () {
	echo '<div role="note" style="background:#7A5A12;color:#fff;font:600 15px/1.4 system-ui,sans-serif;text-align:center;padding:10px 16px">'
		. 'Vista previa del nuevo diseño. No es la web oficial: las noticias son de ejemplo y algunos datos están pendientes de confirmar. '
		. '<a href="https://sanromandelosmontes.org/" style="color:#fff;text-decoration:underline">Ir a la web oficial</a></div>';
} );
add_action( 'wp_head', function () {
	echo '<meta name="robots" content="noindex, nofollow">' . "\n";
} );
