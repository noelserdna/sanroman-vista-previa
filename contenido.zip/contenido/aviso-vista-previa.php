<?php
/**
 * Plugin Name: Aviso de vista previa
 * Description: Franja que indica que esta web es una maqueta de diseño, no la web oficial.
 */
add_action( 'wp_body_open', function () {
	echo '<div role="note" style="background:#7A5A12;color:#fff;font:600 14px/1.4 system-ui,sans-serif;text-align:center;padding:6px 16px">'
		. 'Vista previa del nuevo diseño · no es la web oficial · '
		. '<a href="https://sanromandelosmontes.org/" style="color:#fff;text-decoration:underline">Ir a la web oficial</a></div>';
} );
// Que los buscadores no la confundan con la web oficial.
add_filter( 'wp_robots', 'wp_robots_no_robots' );
