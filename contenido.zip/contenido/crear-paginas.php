<?php
// Prepara la vista previa en Playground: páginas, portada, noticias de ejemplo.
require '/wordpress/wp-load.php';
require_once ABSPATH . 'wp-admin/includes/media.php';
require_once ABSPATH . 'wp-admin/includes/file.php';
require_once ABSPATH . 'wp-admin/includes/image.php';
wp_set_current_user( 1 ); // Como el administrador: el contenido no se filtra

$dir     = '/wordpress/contenido';
$paginas = json_decode( file_get_contents( "$dir/paginas.json" ), true );
foreach ( $paginas as $p ) {
	if ( get_page_by_path( $p['slug'] ) ) {
		continue;
	}
	wp_insert_post( array(
		'post_type'    => 'page',
		'post_status'  => 'publish',
		'post_name'    => $p['slug'],
		'post_title'   => $p['titulo'],
		'post_content' => file_get_contents( "$dir/{$p['slug']}.html" ),
	) );
}

// Portada estática + página de noticias.
$inicio   = wp_insert_post( array( 'post_type' => 'page', 'post_status' => 'publish', 'post_name' => 'inicio', 'post_title' => 'Inicio', 'post_content' => file_get_contents( "$dir/inicio.html" ) ) );
$noticias = wp_insert_post( array( 'post_type' => 'page', 'post_status' => 'publish', 'post_name' => 'noticias', 'post_title' => 'Noticias y anuncios' ) );
update_option( 'show_on_front', 'page' );
update_option( 'page_on_front', $inicio );
update_option( 'page_for_posts', $noticias );
// Lo mismo que hace el tema al activarse en la web real
sanroman_preparar_portada();

// Categorías de noticias.
$cats = array();
foreach ( array( 'Anuncios', 'Actividades', 'Cultura', 'Obras', 'Deporte', 'Fiestas' ) as $nombre ) {
	$t                = wp_insert_term( $nombre, 'category' );
	$cats[ $nombre ] = is_wp_error( $t ) ? (int) $t->get_error_data() : $t['term_id'];
}
wp_delete_post( 1, true ); // «Hola, mundo»
wp_delete_post( 2, true ); // Página de ejemplo
wp_delete_term( 1, 'category' ); // «Sin categoría»

// Noticias de EJEMPLO solo para ver la maqueta (no son reales).
$tema    = get_theme_file_path( 'assets/img/' );
$ejemplo = array(
	array( 'Cultura', 'Ejemplo: abierta la inscripción para el certamen literario', 'casona.jpg', '-2 days' ),
	array( 'Anuncios', 'Ejemplo: horario de invierno de las oficinas municipales', '', '-5 days' ),
	array( 'Actividades', 'Ejemplo: ruta senderista por la Sierra de San Vicente', 'ermita.jpg', '-9 days' ),
	array( 'Obras', 'Ejemplo: mejoras en la piscina municipal antes del verano', 'piscina.jpg', '-14 days' ),
	array( 'Fiestas', 'Ejemplo: programa de fiestas de San Román', 'iglesia.jpg', '-20 days' ),
);
foreach ( $ejemplo as list( $cat, $titulo, $foto, $cuando ) ) {
	$id = wp_insert_post( array(
		'post_status'   => 'publish',
		'post_title'    => $titulo,
		'post_date'     => gmdate( 'Y-m-d H:i:s', strtotime( $cuando ) ),
		'post_excerpt'  => 'Texto de ejemplo para ver cómo queda la entradilla de una noticia en la portada y en el listado.',
		'post_content'  => "<!-- wp:paragraph -->\n<p>Esta es una noticia de ejemplo creada solo para la vista previa del diseño.</p>\n<!-- /wp:paragraph -->",
		'post_category' => array( $cats[ $cat ] ),
	) );
	if ( $foto ) {
		$copia = wp_tempnam( $foto );
		copy( $tema . $foto, $copia );
		$adjunto = media_handle_sideload( array( 'name' => $foto, 'tmp_name' => $copia ), $id );
		if ( ! is_wp_error( $adjunto ) ) {
			set_post_thumbnail( $id, $adjunto );
		}
	}
}

update_option( 'blogname', 'Ayuntamiento de San Román de los Montes' );
update_option( 'blogdescription', 'Página web oficial del Ayuntamiento' );
global $wp_rewrite;
$wp_rewrite->set_permalink_structure( '/%postname%/' );
$wp_rewrite->flush_rules( true );
